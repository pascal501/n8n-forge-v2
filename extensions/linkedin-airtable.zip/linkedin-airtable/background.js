// Service Worker

importScripts("pdf-generator.js");

// ─── Airtable ─────────────────────────────────────────────────────────────────

async function airtableRequest(token, method, path, body = null) {
  const opts = {
    method,
    headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
  };
  if (body) opts.body = JSON.stringify(body);
  const resp = await fetch(`https://api.airtable.com/v0${path}`, opts);
  const json = await resp.json();
  if (!resp.ok) throw new Error(json.error?.message || JSON.stringify(json));
  return json;
}

async function getFieldId(token, baseId, tableId, fieldName) {
  const key = `fids_${baseId}_${tableId}`;
  const stored = await chrome.storage.local.get(key);
  let map = stored[key];
  if (!map) {
    const schema = await airtableRequest(token, "GET", `/meta/bases/${baseId}/tables`);
    const table  = schema.tables?.find(t => t.id === tableId);
    if (!table) throw new Error(`Table ${tableId} introuvable`);
    map = {};
    table.fields.forEach(f => { map[f.name] = f.id; });
    await chrome.storage.local.set({ [key]: map });
  }
  return map[fieldName] || null;
}

async function uploadAttachment(token, baseId, tableId, recordId, fieldName, filename, dataUrl) {
  const fieldId = await getFieldId(token, baseId, tableId, fieldName);
  if (!fieldId) throw new Error(`Champ "${fieldName}" introuvable — ajoutez le scope schema.bases:read à votre token Airtable`);
  const [meta, b64] = dataUrl.split(",");
  const contentType = meta.replace("data:", "").replace(";base64", "");
  const resp = await fetch(
    `https://content.airtable.com/v0/${baseId}/${recordId}/${fieldId}/uploadAttachment`,
    {
      method: "POST",
      headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
      body: JSON.stringify({ contentType, filename, file: b64 }),
    }
  );
  const json = await resp.json();
  if (!resp.ok) throw new Error(json.error?.message || JSON.stringify(json));
  return json;
}

// Cherche un contact existant par son URL LinkedIn (gestion des doublons)
// Retourne l'ID du record si trouvé, sinon null.
async function findExistingRecord(token, baseId, tableId, linkedinUrl) {
  if (!linkedinUrl) return null;
  // Échappe les guillemets pour la formule Airtable
  const safeUrl = linkedinUrl.replace(/"/g, '\\"');
  const formula = `{LinkedIn URL} = "${safeUrl}"`;
  const path = `/${baseId}/${tableId}?filterByFormula=${encodeURIComponent(formula)}&maxRecords=1`;
  try {
    const result = await airtableRequest(token, "GET", path);
    return result.records?.[0]?.id || null;
  } catch (e) {
    console.warn("[LinkedIn→Airtable] Recherche doublon échouée:", e.message);
    return null; // en cas d'erreur, on crée un nouveau record
  }
}

// ─── Extras via onglet background : email, téléphone, contacts en commun ──────
// Un seul onglet caché pour tout :
//   1. charge le profil → clique "Coordonnées" → lit mailto:/tel:
//   2. navigue vers la page des relations en commun → scrape noms + URLs

async function getProfileExtras(linkedinUrl, mutualUrl) {
  const profileUrl = linkedinUrl.replace(/\/$/, "").split("?")[0] + "/";
  const tab = await chrome.tabs.create({ url: profileUrl, active: false });
  const out = { email: "", phone: "", website: "", mutualContacts: [] };

  // Helper : attend que l'onglet ait fini de charger
  function waitTabComplete(timeoutMs = 15000) {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error("Tab load timeout")), timeoutMs);
      function onUpdate(tabId, info) {
        if (tabId === tab.id && info.status === "complete") {
          chrome.tabs.onUpdated.removeListener(onUpdate);
          clearTimeout(timer);
          resolve();
        }
      }
      chrome.tabs.onUpdated.addListener(onUpdate);
    });
  }

  try {
    await waitTabComplete();
    await new Promise(r => setTimeout(r, 3000)); // attend React

    // ── 1. Coordonnées ───────────────────────────────────────────────────────
    const clicked = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const link = Array.from(document.querySelectorAll("a"))
          .find(a => /^(Coordonnées|Contact info)$/i.test((a.innerText || "").trim()));
        if (link) { link.click(); return true; }
        return false;
      },
    });

    if (clicked[0]?.result) {
      await new Promise(r => setTimeout(r, 2500));
      const contact = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          // Cible le panneau modal des coordonnées (sinon tout le document)
          const modal = document.querySelector('[role="dialog"], .artdeco-modal') || document;

          // EMAIL — le href mailto: est fiable
          const emailA = modal.querySelector('a[href^="mailto:"]');
          const email = emailA?.href?.replace("mailto:", "").trim() || "";

          // NB : sur LinkedIn, les liens Website/Téléphone affichent la bonne valeur
          // en TEXTE mais leur href est une redirection LinkedIn → on parse le texte
          // de la section concernée, pas le href.
          let phone = "", website = "";
          modal.querySelectorAll("section, li, div").forEach(sec => {
            const t = (sec.innerText || "").trim();
            // SITE WEB
            if (!website && /^(Site web|Website|Site internet)/i.test(t)) {
              const m = t.match(/https?:\/\/[^\s)]+/);
              if (m && !/linkedin\.com/i.test(m[0])) website = m[0];
            }
            // TÉLÉPHONE
            if (!phone && /^(Téléphone|Phone|Mobile|Portable|Tél)/i.test(t)) {
              const m = t.match(/[\+\d][\d\s\-\.\(\)]{6,20}/);
              if (m) phone = m[0].trim();
            }
          });
          // Fallback téléphone : lien tel: si le parsing texte n'a rien donné
          if (!phone) {
            const phoneA = modal.querySelector('a[href^="tel:"]');
            if (phoneA) phone = phoneA.href.replace("tel:", "").trim();
          }

          return { email, phone, website };
        },
      });
      if (contact[0]?.result) {
        out.email   = contact[0].result.email   || "";
        out.phone   = contact[0].result.phone   || "";
        out.website = contact[0].result.website || "";
      }
    }

    // ── 2. Contacts en commun ─────────────────────────────────────────────────
    if (mutualUrl) {
      await chrome.tabs.update(tab.id, { url: mutualUrl });
      await waitTabComplete();
      await new Promise(r => setTimeout(r, 2500)); // attend les résultats

      const mutual = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          const seen = new Set();
          const list = [];
          document.querySelectorAll('a[href*="/in/"]').forEach(a => {
            const href = (a.href || "").split("?")[0];
            // Nom = 1ère ligne, nettoyée du degré de relation
            let name = (a.innerText || "").trim().split("\n")[0].trim();
            name = name.replace(/\s*[•·]\s*\d+(er|e|nd|rd|th)?\s*$/i, "")    // "• 1er"
                       .replace(/\s*\d+(er|e|nd|rd|th)\s*$/i, "")
                       .trim();
            if (!href.includes("/in/")) return;
            if (!name || name.length < 2 || name.length > 60) return;
            if (/^(voir|view|membre|member|linkedin)/i.test(name)) return;
            if (seen.has(href)) return;
            seen.add(href);
            list.push({ name, url: href });
          });
          return list.slice(0, 50);
        },
      });
      if (mutual[0]?.result) out.mutualContacts = mutual[0].result;
    }

    return out;
  } catch (e) {
    console.warn("[LinkedIn→Airtable] getProfileExtras:", e.message);
    return out;
  } finally {
    chrome.tabs.remove(tab.id).catch(() => {});
  }
}

// ─── Résumé du profil via Gemini (modèle gratuit gemini-2.0-flash) ────────────
// 3 prompts distincts selon la classification : Prospect (client/vente), Ressource (RH/placement), Généraliste
async function generateGeminiSummary(apiKey, profile, mutualContacts, classifications = {}) {
  const mutualNames = (mutualContacts || []).map(c => c.name).join(", ");

  // Données du profil envoyées à Gemini
  const profileData = [
    `Nom : ${profile.fullName || ""}`,
    `Poste actuel : ${profile.position || ""}`,
    `Entreprise actuelle : ${profile.company || ""}`,
    profile.summary ? `À propos / Parcours : ${profile.summary}` : "",
    mutualNames ? `Relations en commun : ${mutualNames}` : "",
  ].filter(Boolean).join("\n");

  let prompt;

  if (classifications.prospect && !classifications.resource) {
    // ── PROSPECT : orientation CLIENT/VENTE ────────────────────────────────
    prompt =
      "Tu rédiges une **fiche d'approche client** pour un commercial ESN qui veut le prospecter. " +
      "Cette personne est un client/décideur potentiel. À partir des données ci-dessous, " +
      "rédige en français un résumé court (5 à 7 phrases) qui identifie :\n" +
      "1. **Qui est cette personne ?** Rôle, responsabilités, pouvoir de décision probable ?\n" +
      "2. **Secteur & contexte business** : Quels enjeux IT/digitaux pour son industrie ?\n" +
      "3. **Expertise/parcours** : Quels domaines a-t-il couverts ? Ça dit quoi sur ses besoins IT ?\n" +
      "4. **Stabilité/positionnement** : Est-il en poste stable ? En transition ? Signal de changement ?\n" +
      "5. **Angle commercial** : Comment l'aborder ? Quel besoin/solution ESN pourrait l'intéresser ?\n" +
      "6. **Connexions** : Y a-t-il des relations en commun pour une warm intro ?\n\n" +
      "Sois stratégique et commercial. Focus : comment le vendre à ce client potentiel ?\n\n--- CLIENT/PROSPECT ---\n" + profileData;

  } else if (classifications.resource && !classifications.prospect) {
    // ── RESSOURCE : orientation RH/PLACEMENT ───────────────────────────────
    prompt =
      "Tu rédiges une **fiche candidat** pour un commercial ESN qui veut le placer en mission. " +
      "À partir des données ci-dessous, rédige en français un résumé court (5 à 7 phrases) qui couvre :\n" +
      "1. **Expérience totale en années** (extrais du texte)\n" +
      "2. **Séniorité/niveau** (junior, confirmé, senior, expert/lead)\n" +
      "3. **Stack technique & compétences** (langages, frameworks, domaines IT maîtrisés)\n" +
      "4. **Parcours & anciennes boîtes** (trajectoire, secteurs, croissance, stabilité)\n" +
      "5. **Profil de mobilité** : Cherche de la stabilité ? Du leadership ? Spécialisation ? Polyvalence ?\n" +
      "6. **Positionnement placement** : Pour quel type de mandat/mission/client le proposer ?\n\n" +
      "Sois clair sur la valeur placement/RH. Focus : pour quel mandat/client le matcher ?\n\n--- RESSOURCE/CANDIDAT ---\n" + profileData;

  } else {
    // ── GÉNÉRALISTE : résumé neutre, équilibré ────────────────────────────
    prompt =
      "Tu rédiges une **fiche de synthèse généraliste** sur cette personne. " +
      "À partir des données ci-dessous, rédige en français un résumé court (5 à 7 phrases) qui couvre :\n" +
      "1. **Profil général** : poste, entreprise, séniorité\n" +
      "2. **Expérience en années & domaines** couverts\n" +
      "3. **Parcours professionnel** : anciennes boîtes, trajectoire générale\n" +
      "4. **Contexte actuel** : stabilité, changements visibles, évolution en cours ?\n" +
      "5. **Caractéristiques clés** : ce qui le définit professionnellement\n" +
      "6. **Relations** : connexions en commun si pertinentes ?\n\n" +
      "Sois factuel, neutre, sans orientation commerciale particulière.\n\n--- PROFIL ---\n" + profileData;
  }

  const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${encodeURIComponent(apiKey)}`;
  const resp = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [{ parts: [{ text: prompt }] }],
      generationConfig: { temperature: 0.4, maxOutputTokens: 500 },
    }),
  });
  const json = await resp.json();
  if (!resp.ok) throw new Error(json.error?.message || `Gemini HTTP ${resp.status}`);
  const txt = json.candidates?.[0]?.content?.parts?.[0]?.text?.trim();
  if (!txt) throw new Error("Réponse Gemini vide");
  return txt;
}

// Formate les contacts en commun en markdown (liens cliquables si champ rich text)
function formatMutualContacts(contacts) {
  if (!contacts || contacts.length === 0) return "";
  return contacts.map(c => `[${c.name}](${c.url})`).join("; ");
}

// ─── PDF natif LinkedIn ───────────────────────────────────────────────────────
// CORRECTION CLÉ : l'interception window.fetch DOIT se faire dans le monde
// PRINCIPAL de la page (world:"MAIN") — les content scripts sont dans un monde
// isolé et ne capturent pas les requêtes fetch du code JavaScript de LinkedIn.
//
// Flow :
//   1. Inject listener postMessage dans le monde isolé (a accès à chrome.runtime)
//   2. Inject intercepteur fetch dans le monde principal (a accès au vrai window.fetch)
//   3. Clique Plus → Enregistrer au format PDF
//   4. Intercepteur capte la réponse RSC → extrait URL ambry → fetch PDF
//   5. postMessage → relay vers background via chrome.runtime.sendMessage

async function getNativePDF(tabId) {
  const nonce = "pdf_" + Date.now();

  // Promise résolue quand le background reçoit le message relay
  const pdfPromise = new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      chrome.runtime.onMessage.removeListener(relay);
      reject(new Error("PDF timeout 25s"));
    }, 25000);

    function relay(msg) {
      if (msg._pdfNonce === nonce) {
        chrome.runtime.onMessage.removeListener(relay);
        clearTimeout(timer);
        msg.success ? resolve(msg.data) : reject(new Error(msg.error || "PDF failed"));
      }
    }
    chrome.runtime.onMessage.addListener(relay);
  });

  // 1. Monde isolé : écoute postMessage et le relaie au background
  await chrome.scripting.executeScript({
    target: { tabId },
    func: (nonce) => {
      window.addEventListener("message", function pdfRelay(e) {
        if (e.data?._pdfNonce === nonce) {
          window.removeEventListener("message", pdfRelay);
          chrome.runtime.sendMessage(e.data);
        }
      });
    },
    args: [nonce],
  });

  // 2. Monde PRINCIPAL : intercepte window.fetch de LinkedIn
  await chrome.scripting.executeScript({
    target: { tabId },
    world: "MAIN",
    func: (nonce) => {
      const orig = window.fetch;
      let done = false;

      window.fetch = async function (...args) {
        const resp = await orig.apply(this, args);
        const url = typeof args[0] === "string" ? args[0] : (args[0]?.url || "");

        if (!done && (url.includes("server-request") || url.includes("rsc-action"))) {
          resp.clone().text().then(async text => {
            const m = text.match(/https:\/\/www\.linkedin\.com\/ambry\/\?[^"\\}\s]{20,}/);
            if (!m || done) return;
            done = true;
            window.fetch = orig;

            try {
              const pr = await orig(m[0], { credentials: "include" });
              const bl = await pr.blob();
              const fr = new FileReader();
              fr.onloadend = () => {
                window.postMessage({ _pdfNonce: nonce, success: true, data: fr.result }, "*");
              };
              fr.readAsDataURL(bl);
            } catch (e) {
              window.postMessage({ _pdfNonce: nonce, success: false, error: e.message }, "*");
            }
          }).catch(e => {
            window.postMessage({ _pdfNonce: nonce, success: false, error: e.message }, "*");
          });
        }
        return resp;
      };
    },
    args: [nonce],
  });

  // 3. Clique Plus → Enregistrer au format PDF
  await chrome.scripting.executeScript({
    target: { tabId },
    func: () => {
      const plusBtns = Array.from(document.querySelectorAll("button"))
        .filter(b => b.innerText?.trim() === "Plus");
      (plusBtns[1] || plusBtns[0])?.click();
      setTimeout(() => {
        Array.from(document.querySelectorAll("div, li, [role=menuitem]"))
          .find(el => el.innerText?.trim() === "Enregistrer au format PDF")?.click();
      }, 700);
    },
  });

  return pdfPromise;
}

// ─── Handler principal ────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "saveToAirtable") {
    handleSave(request.profile, request.config, request.tabId, request.classifications)
      .then(r => sendResponse({ success: true, recordId: r.id, details: r.details }))
      .catch(e => sendResponse({ success: false, error: e.message }));
    return true;
  }
});

async function handleSave(profile, config, tabId, classifications = {}) {
  const { token, baseId, tableId, geminiKey } = config;
  const details = { email: false, phone: false, photo: false, pdf: false,
                    pdfSource: "", mutual: 0, summary: "" };

  // 1. Extras via onglet caché : email, téléphone, site web, contacts en commun
  let email = "", phone = "", website = "", mutualContacts = [];
  if (profile.linkedinUrl) {
    const extras = await getProfileExtras(profile.linkedinUrl, profile.mutualUrl);
    if (extras.email) { email = extras.email; details.email = true; }
    if (extras.phone) {
      // Nettoyage du téléphone : chiffres seulement
      phone = extras.phone.replace(/[^0-9]/g, "");
      if (phone) details.phone = true;
    }
    if (extras.website) { website = extras.website; details.website = true; }
    mutualContacts = extras.mutualContacts || [];
    details.mutual = mutualContacts.length;
  }

  // 2. Résumé IA via Gemini (si clé configurée), sinon on garde le "À propos" scrapé
  let profileSummary = profile.summary || "";
  if (geminiKey) {
    try {
      profileSummary = await generateGeminiSummary(geminiKey, profile, mutualContacts, classifications);
      details.summary = "Gemini";
    } catch (e) {
      console.warn("[LinkedIn→Airtable] Gemini:", e.message);
      details.summaryError = e.message;
      details.summary = profile.summary ? "À propos (Gemini échoué)" : "";
    }
  } else if (profile.summary) {
    details.summary = "À propos";
  }

  // 3. Champs texte
  const fields = {};
  // Profile Name : "Prénom Nom" (titre de la fiche)
  if (profile.fullName) fields["Profile Name"] = profile.fullName;
  if (profile.firstName)   fields["Prénom"]         = profile.firstName;
  if (profile.lastName)    fields["Nom"]             = profile.lastName;
  if (profile.position)    fields["Poste"]           = profile.position;
  if (profile.company)     fields["Entreprise"]      = profile.company;
  if (profile.location)    fields["Location"]        = profile.location;
  if (profile.linkedinUrl) fields["LinkedIn URL"]    = profile.linkedinUrl;
  if (profileSummary)      fields["Profile Summary"] = profileSummary;
  if (email)               fields["Email"]           = email;
  if (phone)               fields["Téléphone"]       = phone;
  if (website)             fields["Site web"]        = website;

  // Contacts en commun (markdown : cliquable si le champ est en rich text)
  const mutualMd = formatMutualContacts(mutualContacts);
  if (mutualMd) fields["Contacts en communs"] = mutualMd;

  // Checkboxes : Confirmed as Prospect / Confirmed as Resource
  if (classifications.prospect !== undefined) fields["Confirmed as Prospect"] = classifications.prospect;
  if (classifications.resource !== undefined) fields["Confirmed as Resource"] = classifications.resource;

  // 3. Photo (le PATCH/POST avec [{url}] remplace le contenu du champ pièce jointe)
  if (profile.photoUrl) {
    fields["Photo Profile"] = [{ url: profile.photoUrl, filename: "photo.jpg" }];
    details.photo = true;
  }

  // 4. Doublon ? Cherche un contact existant par URL LinkedIn
  const existingId = await findExistingRecord(token, baseId, tableId, profile.linkedinUrl);

  let recordId;
  if (existingId) {
    // ── MISE À JOUR du contact existant ──────────────────────────────────────
    details.mode = "mise à jour";
    // Vide le champ Profile PDF avant le re-upload (sinon Airtable cumule les PJ)
    fields["Profile PDF"] = [];
    const updated = await airtableRequest(
      token, "PATCH", `/${baseId}/${tableId}`,
      { records: [{ id: existingId, fields }] }
    );
    recordId = updated.records[0].id;
  } else {
    // ── CRÉATION d'un nouveau contact ────────────────────────────────────────
    details.mode = "création";
    const created = await airtableRequest(token, "POST", `/${baseId}/${tableId}`, { fields });
    recordId = created.id;
  }

  // 5. PDF natif LinkedIn
  const pdfName = (profile.fullName || "profil").replace(/[^a-zA-Z0-9 _\-]/g, "").trim() + ".pdf";
  let pdfDataUrl = null;

  if (tabId) {
    try {
      const b64 = await getNativePDF(tabId);
      if (b64?.includes("base64,")) {
        pdfDataUrl = b64;
        details.pdfSource = "natif LinkedIn ✓";
        details.pdf = true;
      }
    } catch (e) {
      console.warn("[LinkedIn→Airtable] PDF natif:", e.message, "→ fallback");
      details.pdfError = e.message;
    }
  }

  // Fallback : PDF généré
  if (!pdfDataUrl) {
    try {
      const txt = generateProfilePDF({ ...profile, email, phone });
      pdfDataUrl = `data:application/pdf;base64,${btoa(txt)}`;
      details.pdfSource = "généré localement";
      details.pdf = true;
    } catch (e) {
      console.error("[LinkedIn→Airtable] PDF fallback:", e.message);
    }
  }

  if (pdfDataUrl) {
    try {
      await uploadAttachment(token, baseId, tableId, recordId, "Profile PDF", pdfName, pdfDataUrl);
    } catch (e) {
      details.pdf = false;
      details.pdfError = e.message;
      console.error("[LinkedIn→Airtable] Upload PDF:", e.message);
    }
  }

  return { id: recordId, details };
}
