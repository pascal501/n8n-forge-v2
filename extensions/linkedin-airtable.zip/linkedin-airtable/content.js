// Content script LinkedIn — scraping robuste

(function () {

  function text(el) {
    return el ? (el.innerText || el.textContent || "").trim() : "";
  }

  function waitFor(sel, ms = 3000) {
    return new Promise(resolve => {
      const el = document.querySelector(sel);
      if (el) return resolve(el);
      const obs = new MutationObserver(() => {
        const found = document.querySelector(sel);
        if (found) { obs.disconnect(); resolve(found); }
      });
      obs.observe(document.body, { childList: true, subtree: true });
      setTimeout(() => { obs.disconnect(); resolve(null); }, ms);
    });
  }

  // ── Scraping principal (texte + photo) ─────────────────────────────────────
  async function scrapeProfile() {
    await waitFor("main", 3000);
    await new Promise(r => setTimeout(r, 800));

    const p = {};

    // Nom (LinkedIn utilise H2, pas H1)
    const nameEl = Array.from(document.querySelectorAll("main h2")).find(el => {
      const t = text(el);
      return t.length > 2 && !t.match(/^(Activit|Exp|Formation|Comp|Recomm|Centres)/i);
    });
    p.fullName = text(nameEl);
    const parts = p.fullName.split(/\s+/);
    const last = parts[parts.length - 1];
    if (last === last.toUpperCase() && last.length > 1) {
      p.lastName = last; p.firstName = parts.slice(0, -1).join(" ");
    } else {
      p.firstName = parts[0] || ""; p.lastName = parts.slice(1).join(" ") || "";
    }

    // Poste + Entreprise (premier <P> substantiel)
    const ps = Array.from(document.querySelectorAll("main p"));
    const posEl = ps.find(el => {
      const t = text(el);
      return t.length > 15 && !t.startsWith("·") && !t.match(/^\d/);
    });
    const posText = text(posEl);
    let split = false;
    for (const sep of [" chez ", " at ", " @ "]) {
      if (posText.includes(sep)) {
        const i = posText.indexOf(sep);
        p.position = posText.substring(0, i).trim();
        p.company  = posText.substring(i + sep.length).trim();
        split = true; break;
      }
    }
    if (!split) {
      p.position = posText;
      const idx = ps.indexOf(posEl);
      p.company = idx >= 0 ? text(ps[idx + 1]).split("·")[0].trim() : "";
    }

    p.linkedinUrl = location.href.split("?")[0];

    // Localisation — elle se trouve sous le poste, dans le même conteneur que le
    // lien "Coordonnées", au format "Ville, Région · Coordonnées"
    p.location = "";
    // Méthode 1 (sémantique, fiable) : conteneur du lien Coordonnées → texte avant le "·"
    const coordLink = Array.from(document.querySelectorAll("main a")).find(a =>
      /^(Coordonnées|Contact info)$/i.test((a.innerText || "").trim()) ||
      (a.href || "").includes("contact-info"));
    if (coordLink) {
      const container = coordLink.closest("div");
      if (container) {
        const raw = (container.innerText || "").split("·")[0].trim();
        // Garde-fou : pas de contacts en commun ni de relations capturés par erreur
        if (raw && raw.length < 100 && !/relation|contact|coordonn/i.test(raw)) {
          p.location = raw;
        }
      }
    }
    // Méthode 2 (fallback) : span dédié à la localisation (classes utilitaires LinkedIn)
    if (!p.location) {
      const locSpan = document.querySelector(
        "span.text-body-small.inline.t-black--light.break-words");
      if (locSpan) {
        const raw = (locSpan.innerText || "").trim();
        if (raw && raw.length < 100 && !/relation|contact/i.test(raw)) p.location = raw;
      }
    }

    // Photo du profil — cherche dans le bloc principal en haut (pas dans les posts/articles)
    // La vraie photo est généralement dans une balise img avec alt="Voir le profil de [Nom]"
    // ou la plus grande image avec "profile-displayphoto" dans l'URL, en haut de la page
    p.photoUrl = "";

    // Sélecteur 1 : image avec alt exact du profil
    const photoByAlt = document.querySelector(`img[alt^="Voir le profil de"]`);
    if (photoByAlt) {
      const src = photoByAlt.src || "";
      if (src.includes("profile-displayphoto")) p.photoUrl = src;
    }

    // Sélecteur 2 : Fallback — cherche "profile-displayphoto" dans le main, en excluant les posts
    if (!p.photoUrl) {
      const profilePhotos = Array.from(document.querySelectorAll("main img"))
        .filter(img => {
          const src = img.src || "";
          const alt = (img.alt || "").toLowerCase();
          // profile-displayphoto mais pas dans un article/post
          return src.includes("profile-displayphoto") &&
                 !src.includes("feedshare") && // exclut les posts
                 !alt.includes("article") && !alt.includes("post");
        });

      if (profilePhotos.length > 0) {
        // Prend la première trouvée dans le DOM (la plus haute)
        p.photoUrl = profilePhotos[0].src;
      }
    }

    // Résumé — LinkedIn place un ancre id="about" avant la section
    p.summary = "";
    const aboutAnchor = document.getElementById("about");
    if (aboutAnchor) {
      const sec = aboutAnchor.closest("section") || aboutAnchor.parentElement;
      if (sec) {
        const spans = sec.querySelectorAll("span[aria-hidden='true']");
        const raw = spans.length > 0
          ? Array.from(spans).map(s => text(s)).filter(Boolean).join(" ")
          : text(sec).replace(/^(À propos|About)\s*/i, "").trim();
        if (raw.length > 20) p.summary = raw;
      }
    }
    // Fallback : cherche la section par son titre
    if (!p.summary) {
      for (const sec of document.querySelectorAll("main section")) {
        const h = sec.querySelector("h2, h3");
        if (h && /^(À propos|About)$/i.test(text(h).trim())) {
          const raw = text(sec).replace(/^(À propos|About)\s*/i, "").trim();
          if (raw.length > 20) { p.summary = raw; break; }
        }
      }
    }

    // Email + Téléphone : gérés côté background via onglet dédié
    // (LinkedIn rend le contenu en JS, un simple fetch ne suffit pas)
    p.email = ""; p.phone = "";

    // URL vers la page des relations en commun (la liste complète est scrapée
    // côté background). Le lien contient un paramètre connectionOf spécifique.
    p.mutualUrl = "";
    const mutualLink = Array.from(document.querySelectorAll("main a"))
      .find(a => /relation.*commun|relations? en commun|mutual connection/i.test(a.innerText || ""));
    if (mutualLink) p.mutualUrl = mutualLink.href;

    return p;
  }

  // ── Listeners ──────────────────────────────────────────────────────────────
  // Le PDF natif est désormais géré entièrement dans background.js
  // via chrome.scripting.executeScript world:"MAIN" (seule façon d'intercepter
  // le vrai window.fetch de LinkedIn — les content scripts sont dans un monde isolé)
  chrome.runtime.onMessage.addListener((req, _sender, sendResponse) => {
    if (req.action === "scrapeProfile") {
      scrapeProfile()
        .then(data => sendResponse({ success: true, data }))
        .catch(err  => sendResponse({ success: false, error: err.message }));
      return true;
    }
  });

})();
