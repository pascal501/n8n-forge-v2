// options.js — sauvegarde et chargement de la config dans chrome.storage.sync

document.addEventListener("DOMContentLoaded", () => {
  // Charge les valeurs existantes
  chrome.storage.sync.get(["airtableToken", "baseId", "tableId", "geminiKey"], (data) => {
    if (data.airtableToken) document.getElementById("airtableToken").value = data.airtableToken;
    if (data.baseId) document.getElementById("baseId").value = data.baseId;
    if (data.tableId) document.getElementById("tableId").value = data.tableId;
    if (data.geminiKey) document.getElementById("geminiKey").value = data.geminiKey;
  });

  document.getElementById("btn-save").addEventListener("click", () => {
    const token = document.getElementById("airtableToken").value.trim();
    const baseId = document.getElementById("baseId").value.trim();
    const tableId = document.getElementById("tableId").value.trim();
    const geminiKey = document.getElementById("geminiKey").value.trim();
    const status = document.getElementById("status");

    if (!token || !baseId || !tableId) {
      status.textContent = "Token, Base ID et Table ID sont requis.";
      status.className = "error";
      return;
    }

    chrome.storage.sync.set({ airtableToken: token, baseId, tableId, geminiKey }, () => {
      status.textContent = "✓ Paramètres enregistrés";
      status.className = "success";
      setTimeout(() => { status.className = ""; status.textContent = ""; }, 3000);
    });
  });
});
