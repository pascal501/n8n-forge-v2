// popup.js — orchestration : scrape → affichage → confirmation → envoi

const states = ["loading", "wrong-page", "no-config", "data", "saving", "success", "error"];

function showState(name) {
  states.forEach((s) => {
    const el = document.getElementById(`state-${s}`);
    if (el) el.classList.toggle("active", s === name);
  });
}

function fillField(id, value) {
  const el = document.getElementById(id);
  if (!el) return;
  if (value) {
    el.textContent = value;
    el.classList.remove("empty");
  } else {
    el.textContent = "—";
    el.classList.add("empty");
  }
}

let currentProfile = null;
let currentConfig = null;

// ─── Init ─────────────────────────────────────────────────────────────────────

document.addEventListener("DOMContentLoaded", async () => {
  // Boutons
  document.getElementById("btn-cancel").addEventListener("click", () => window.close());
  document.getElementById("btn-save").addEventListener("click", saveContact);
  document.getElementById("btn-retry").addEventListener("click", init);
  document.getElementById("btn-open-options")?.addEventListener("click", () => {
    chrome.runtime.openOptionsPage();
  });

  await init();
});

async function init() {
  showState("loading");

  // 1. Vérifie la config
  const config = await loadConfig();
  if (!config) {
    showState("no-config");
    return;
  }
  currentConfig = config;

  // 2. Vérifie qu'on est sur un profil LinkedIn
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.url?.match(/linkedin\.com\/in\//)) {
    showState("wrong-page");
    return;
  }

  // 3. Lance le scraping
  //    Le content script est auto-injecté par Chrome (déclaré dans manifest.json)
  //    Si la page vient d'être chargée, on inject manuellement en fallback.
  let result;
  const trySend = () => chrome.tabs.sendMessage(tab.id, { action: "scrapeProfile" });

  try {
    result = await trySend();
  } catch {
    try {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] });
      await new Promise(r => setTimeout(r, 400));
      result = await trySend();
    } catch (e) {
      showError("Rechargez la page LinkedIn puis réessayez. (" + e.message + ")");
      return;
    }
  }

  if (!result?.success) {
    showError("Scraping échoué. Assurez-vous d'être sur une page de profil LinkedIn.");
    return;
  }

  currentProfile = result.data;
  displayProfile(currentProfile);
  showState("data");
}

// ─── Affichage ────────────────────────────────────────────────────────────────

function displayProfile(p) {
  fillField("f-fullName", p.fullName);
  fillField("f-position", p.position);
  fillField("f-company", p.company);
  fillField("f-email", p.email);
  fillField("f-phone", p.phone);
  fillField("f-linkedinUrl", p.linkedinUrl);

  const img = document.getElementById("photo-img");
  const placeholder = document.getElementById("photo-placeholder");
  if (p.photoBase64) {
    img.src = p.photoBase64;
    img.style.display = "block";
    placeholder.style.display = "none";
  } else {
    img.style.display = "none";
    placeholder.style.display = "inline-flex";
  }
}

// ─── Sauvegarde ───────────────────────────────────────────────────────────────

async function saveContact() {
  if (!currentProfile || !currentConfig) return;

  showState("saving");

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const response = await chrome.runtime.sendMessage({
    action: "saveToAirtable",
    profile: currentProfile,
    config: currentConfig,
    tabId: tab?.id,
    classifications: {
      prospect: document.getElementById("prospect-check")?.checked || false,
      resource: document.getElementById("resource-check")?.checked || false,
    },
  });

  if (response?.success) {
    const d = response.details || {};
    let msg = currentProfile.fullName || "Contact";
    if (d.mode) msg += ` (${d.mode})`;
    const infos = [];
    if (d.summary === "Gemini") infos.push("résumé IA");
    if (d.mutual)               infos.push(`${d.mutual} en commun`);
    if (d.phone)                infos.push("tél.");
    if (d.website)              infos.push("site web");
    if (infos.length) msg += " — " + infos.join(", ");

    const warnings = [];
    if (d.pdfError)        warnings.push("PDF : " + d.pdfError);
    else if (!d.pdf)       warnings.push("PDF non uploadé");
    if (d.summaryError)    warnings.push("Gemini : " + d.summaryError);
    if (!d.email && currentProfile.linkedinUrl) warnings.push("Email non trouvé");

    document.getElementById("success-name").textContent =
      msg + (warnings.length ? "\n⚠ " + warnings.join(" | ") : "");
    // Met à jour le titre de l'état succès selon le mode
    const h2 = document.querySelector("#state-success h2");
    if (h2) h2.textContent = d.mode === "mise à jour" ? "Contact mis à jour !" : "Contact enregistré !";
    showState("success");
  } else {
    showError(response?.error || "Erreur inconnue");
  }
}

function showError(msg) {
  document.getElementById("error-msg").textContent = msg;
  showState("error");
}

// ─── Config ───────────────────────────────────────────────────────────────────

function loadConfig() {
  return new Promise((resolve) => {
    chrome.storage.sync.get(["airtableToken", "baseId", "tableId", "geminiKey"], (data) => {
      if (data.airtableToken && data.baseId && data.tableId) {
        resolve({
          token: data.airtableToken,
          baseId: data.baseId,
          tableId: data.tableId,
          geminiKey: data.geminiKey || "",
        });
      } else {
        resolve(null);
      }
    });
  });
}
